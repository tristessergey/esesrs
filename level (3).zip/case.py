#место для твоего кода
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
import plotly
import plotly.express as px
import plotly.graph_objs as go
import os
for dirname, _, filenames in os.walk('DataAnalyst.csv'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

#Чтение дата сета
df = pd.read_csv('DataAnalyst.csv')
df.tail()

df.shape[0]

df.info()
#Только три столбца содержат числовые значения, но такие столбцы как зар.плата должны быть числовыми
df.isnull().sum()
#Здесь несколько потерянных данных, и все 0 равны -1 
df.replace('-1', np.nan, inplace=True)
df.replace(-1, np.nan, inplace=True)
df.replace(-1.0, np.nan, inplace=True)

df.isnull().sum()
#Замена названий
changes_in_table = {'Sr. Data Analyst' : 'Senior Data Analyst', 
                    'Sr Data Analyst' : 'Senior Data Analyst',
                    'Data Analyst Junior' : 'Junior Data Analyst'}

df['Job Title'] = df['Job Title'].map(changes_in_table).fillna(df['Job Title']) 

df['Job Title'].value_counts().head(20)
#Оценка заработной платы
df['Salary Estimate'].value_counts()

df['Salary Estimate'].isnull().sum()

df[df['Salary Estimate'].isnull()]
#Это едниственное значение не важно, так что удаляем его.
df.drop(index = 2149, inplace=True)
#Расчёт средней зар.платы, берём наибольшую и наименьшую и высчитываем среднее число
df['minimal_salary'] = df['Salary Estimate'].str.replace('$', '').str[:3].str.replace('K', '').str.strip().astype('float')

df['maximal_salary'] = df['Salary Estimate'].str[6:10].str.replace('K','').str.lstrip('$').str.strip().astype('float')

df['average_salary'] = (df['minimal_salary'] + df['maximal_salary']) / 2
#
pd.set_option('display.max_colwidth', 10000)
print(df['Job Description'].head())
pd.set_option('display.max_colwidth', 20)
#Нулевые значния
df['Job Description'].isnull().sum()
#Смотрим сколько вакансии на python, power bi, Excel, tableau
options = ['python', 'sql', 'power bi', 'excel', 'tableau']

for option in options:
    df[option] = df['Job Description'].apply(lambda text: option in text.lower())
#Рейтинг
df['Rating'].value_counts().head()

df['Rating'].isnull().sum()
#тут 272 пустых значения, но эти значения к настоящему времени останутся
#Названия компанийъ
df['Company Name'].head()
#Мы видим несколько цифр, это может быть рейтинг
df[['Company Name', 'Rating']].sample(10)
#В этом случае мы можем легко удалить рейтинг в столбцах - "Название компаний"
df['Company Name'] = df['Company Name'].str.split('\n').str[0]
#Ищем потерянные данные в этом столбце
df['Company Name'].isnull().sum()

df[df['Company Name'].isnull()]
#Этот ряд останется. Это может быть полезно даже без названий компаний.
df.columns
#Индустрия
df['Industry'].value_counts()
#Ищем пустые значения
df['Industry'].isnull().sum()
#Здесь 353 пустых значений, но я их оставлю
#Сферы деятильности
df['Sector'].value_counts()
#Снова нулевые значения
df['Sector'].isnull().sum()

df.columns
#Ищем пустые значения 
df.isnull().sum()

df.describe()
#Минимальная заработная плата
#fig = px.histogram(df, x='minimal_salary', marginal='box', 
#                  color_discrete_sequence=['#330C73'])

fig.update_layout(
    
    height=600, width=800, title_text='Minimal Salary',
    
    xaxis_title='salaries', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=18,
            color="black"
        
))

fig.show()
#Максимальная зарплата
fig = px.histogram(df, x='maximal_salary', marginal='box', 
                   color_discrete_sequence=['#330C73'])

fig.update_layout(
    
    height=600, width=800, title_text='Maximal Salary',
    
    xaxis_title='salaries', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=18,
            color="black"
        
))

fig.show()

#Максимальная зарплата равна около 70-95к$, в любом случае распределение также довольно искажено.

#Средняя зарплата
fig = px.histogram(df, x='average_salary', marginal='box', 
                   color_discrete_sequence=['#330C73'])

fig.update_layout(
    
    height=600, width=800, title_text='Average Salary',
    
    xaxis_title='salaries', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=18,
            color="black"
        
))

fig.show()
#Названия работ
fig = go.Figure()

fig.add_trace(go.Bar(x=df['Job Title'].value_counts().head(20).index,
       y=df_analyst['Job Title'].value_counts().head(20).values,
       marker_color = '#330C73'))

fig.update_layout(
    
    height=600, width=800, title_text='Number of job openings by Job Titles',
    
    xaxis_title='job title', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=14,
            color="black"
        
))


fig.show()
#Вакансии по отраслям
fig = go.Figure()

fig.add_trace(go.Bar(x=df_analyst['Industry'].value_counts().head(20).index,
       y=df_analyst['Industry'].value_counts().head(20).values,
       marker_color = '#330C73'))

fig.update_layout(
    
    height=600, width=800, title_text='Number of job openings by Industry',
    
    xaxis_title='job title', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=10,
            color="black"
        
))


fig.show()
#Я увидел что большая часть вакансии это IT технологии, но также имеются в - "Подбору персонала и аутсорсинг - 322", "Медицинские услуги и больницы - 151", "Консультации - 111"
#"компьютерное оборудование и програмное обеспечение- 111"
#Вакансии по секторам
fig = go.Figure()

fig.add_trace(go.Bar(x=df_analyst['Sector'].value_counts().head(20).index,
       y=df_analyst['Sector'].value_counts().head(20).values,
       marker_color = '#330C73'))

fig.update_layout(
    
    height=600, width=800, title_text='Number of job openings by Sector',
    
    xaxis_title='job title', yaxis_title="count", title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=12,
            color="black"
        
))


fig.show()
#Я увидел что информационные технологии являются наиболее распространенными, но имеются и другие - "Бизнес услуги - 523", "Финансы -  169", "Здравоохранение - 151", "Образование - 52"
#"Здравоохранение - 151", "Образование - 52"
#Теперь надо проверить, какие технологии являются наиболее распространёнными и востребоваными
df_copy = df_analyst[['Job Title','python', 'sql','excel','tableau', 'power bi']].copy()
technology = df_copy.groupby('Job Title')[['python', 'sql','excel','tableau', 'power bi']].sum().sort_values(by='python', ascending=False).head(10)
df_technology = pd.DataFrame(technology)
df_technology.reset_index(inplace=True)
df_technology['number_of_job_openings'] = df_analyst['Job Title'].value_counts()[:10].values
df_technology
#В этой таблице мы можем увидеть что почти в каждом 3-м объявлении присутствует - "Python", "sql", "Ms Excel"
fig = px.bar(df_technology, x='Job Title', y=['python', 'sql', 'excel', 'tableau',
                                             'power bi'],
            color_discrete_sequence=px.colors.qualitative.G10)

fig.update_layout(
    
    height=600, width=800, title_text='Number of job openings by Job Title with technologies',
    xaxis_title='job title', yaxis_title="count",
    legend_title='technologies',
    
    font=dict(
            family="Courier New, monospace",
            size=14,
            color="black"
        
))


fig.show()
#Зарплата зависит от рейтинга компании
#Минимальная зарплата
fig = px.scatter(df_analyst, y='Company Name', x='minimal_salary', color = 'Rating',
                 color_continuous_scale=px.colors.sequential.Bluered_r)

fig.update_layout(
    
    height=600, width=800, title_text='Minimal salary and company names with rating scores',
    
    xaxis_title='salary', yaxis_title='Company Name', title_x = 0.5,
    
    font=dict(
            family="Courier New, monospace",
            size=12,
            color="black"
        
))

fig.show()

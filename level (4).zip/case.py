import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns



df = pd.read_csv('StudentsPerfomance.csv')
df.info
df.head(10)

df.describe()

sns.displot(df[score_cols], height=8, aspect=2, kde=True, alpha=0.3)

def plot_hist(df, x, cat_var, alpha=0.5, kde=True):
    sns.histplot(data=df, x=x, alpha=alpha, kde=kde, legend=True, hue=cat_var);
    for value in df[cat_var].unique():
        plt.axvline(df[df[cat_var] == value][x].mean(), linewidth=2, label="mean", alpha=0.8, color='black')
        plt.text(df[df[cat_var] == value][x].mean(), 2, value, rotation=90)

df['gender'].value_counts()

sns.histplot(df['gender'])

plot_hist(df, 'math score', 'gender')

df[df['gender'] == 'male']['math score'].mean() - df[df['gender'] == 'female']['math score'].mean()

plot_hist(df, 'reading score', 'gender')

df[df['gender'] == 'male']['reading score'].mean() - df[df['gender'] == 'female']['reading score'].mean()

plot_hist(df, 'writing score', 'gender')

df[df['gender'] == 'male']['writing score'].mean() - df[df['gender'] == 'female']['writing score'].mean()

df['test preparation course'].value_counts()

sns.histplot(df['test preparation course'])

plot_hist(df, 'math score', 'test preparation course')

df[df['test preparation course'] == 'completed']['math score'].mean() - df[df['test preparation course'] == 'none']['math score'].mean()

plot_hist(df, 'reading score', 'test preparation course')

df[df['test preparation course'] == 'completed']['reading score'].mean() - df[df['test preparation course'] == 'none']['reading score'].mean()

plot_hist(df, 'writing score', 'test preparation course')

df[df['test preparation course'] == 'completed']['writing score'].mean() - df[df['test preparation course'] == 'none']['writing score'].mean()

df['parental level of education'].value_counts()

sns.histplot(df['parental level of education'])

plt.figure(figsize=(25, 10))
plot_hist(df, 'math score', 'parental level of education')

df.groupby('parental level of education').mean()['math score'].sort_values()

plt.figure(figsize=(25, 10))
plot_hist(df, 'reading score', 'parental level of education')

df.groupby('parental level of education').mean()['reading score'].sort_values()

plt.figure(figsize=(25, 10))
plot_hist(df, 'writing score', 'parental level of education')

df.groupby('parental level of education').mean()['writing score'].sort_values()

df['lunch'].value_counts()

sns.histplot(df['lunch'])

plot_hist(df, 'math score', 'lunch')

df[df['lunch'] == 'standard']['math score'].mean() - df[df['lunch'] == 'free/reduced']['math score'].mean()

plot_hist(df, 'reading score', 'lunch')

df[df['lunch'] == 'standard']['reading score'].mean() - df[df['lunch'] == 'free/reduced']['reading score'].mean()

plot_hist(df, 'writing score', 'lunch')

df[df['lunch'] == 'standard']['writing score'].mean() - df[df['lunch'] == 'free/reduced']['writing score'].mean()


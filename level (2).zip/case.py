#место для твоего кода
import pandas as pd
import matplotlib.pyplot as plt
import plotly
import plotly.express as px
df = pd.read_csv('IMDB-Movie-Data.csv', delimiter=',', nrows = 1000)

print(df.info())

df['Revenue (Millions)'].fillna(0, inplace = True)
df['Metascore'].fillna(0, inplace = True)

def s(genre):
    genre = genre.split(';')
    return len(genre)
df['Number of genres'] = df['Genre'].apply(s)

df['Av_rating'] = (df['Rating'] + df['Metascore']) / 2

px.scatter(df,x='Revenue (Millions)',y='Votes',size='Votes', 
           color = 'Rating',#hover_name='Title',
           animation_frame='Year')#,
           #title="Distribution of Revenue and Votes")
#plt.bar(df['Year'], df['Av_rating'])
#plt.show()

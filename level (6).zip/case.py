import pandas as pd 

df = pd.read_csv('StudentsPerformance.csv')
df.info()

df["math score"].max()
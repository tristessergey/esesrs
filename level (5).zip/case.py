import pandas as pd
df = pd.read_csv('DataAnalyst.csv')

data.head(2)
